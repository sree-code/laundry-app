# Slide 9 — Differentiation & Positioning

## Chatbot = FAQ. Copilot = trip rehearsal.

### We win because:

- **Proactive** — mistakes prevented before booking
- **Auditable** — compliance team can verify § references
- **Practical** — travelers carry a passport, not a chat history
- **Built** — working MVP (React + rules engine + policy corpus)

### Future

LLM layer for plain-language + edge-case chat *on top of* cited simulation

---

**Speaker note:** Acknowledge chatbots for open-ended questions; own the high-risk travel lane.
