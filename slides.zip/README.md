# Hackathon Slides — Travel Privilege Copilot

Presentation materials for the hackathon pitch.

| File | Description |
|------|-------------|
| `01-title.md` | Title slide |
| `02-problem.md` | The problem |
| `03-traveler-needs.md` | What travelers need |
| `04-why-not-chatbot.md` | Comparison vs chatbots |
| `05-solution.md` | Our solution |
| `06-demo.md` | Live demo story |
| `07-architecture.md` | How it works |
| `08-impact.md` | Impact metrics |
| `09-differentiation.md` | Positioning |
| `10-close.md` | Closing slide |
| `PITCH-2min.md` | 2-minute spoken script |
| `SLIDES-full.md` | Full deck in one file |

## How to use

1. Copy each slide file into Google Slides or PowerPoint (one slide per file).
2. Or import `SLIDES-full.md` as speaker notes / outline.
3. Read `PITCH-2min.md` while presenting slides 1 → 5 → 6 → 10.

## Design tips

- Dark navy background, white text, blue accent
- Slide 4 (comparison table) = visual centerpiece
- Add app screenshots on slide 6 if available
