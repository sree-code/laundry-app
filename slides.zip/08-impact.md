# Slide 8 — Impact

## Personalized · Accurate · Compliant · Support-friendly

| Metric | Target |
|--------|--------|
| Citation coverage | 100% of simulation steps |
| Golden-path scenarios | Employee, retiree, spouse, partner, peak |
| Time to confidence | < 2 minutes profile → passport |
| Support deflection | Top FAQ scenarios without escalation |
| Escalation quality | Full context, not chat transcript |

---

**Speaker note:** Use "pilot targets" — honest for hackathon scope.
