# Slide 4 — Why Not a Chatbot?

## 14 teams will build a chatbot. Here's the gap.

| Chatbot | Travel Privilege Copilot |
|--------|---------------------------|
| Reactive — user must ask | **Proactive** — simulates before travel |
| One question at a time | **Full trip timeline** in one click |
| Sounds personal | **Actually personalized** (profile + itinerary) |
| LLM may hallucinate | **Rules engine** + **mandatory citations** |
| Chat log at escalation | **Structured context packet** for support |
| Nothing to show at the gate | **Compliance Passport** (printable checklist) |

---

**Speaker note:** This is the slide judges remember. Pause on the table.
