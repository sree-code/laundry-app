# Slide 7 — How It Works (Architecture)

## Accurate because rules decide — AI only explains

```
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│ Profile +   │ ──► │ Rules engine │ ──► │ Trip simulation │
│ Trip input  │     │ (eligibility)│     │ + risk flags    │
└─────────────┘     └──────────────┘     └────────┬────────┘
                                                  │
                    ┌──────────────┐              │
                    │ Policy corpus│ ◄────────────┘
                    │ (RAG-ready)  │   mandatory citations
                    └──────────────┘
```

- **No answer without a policy citation**
- Policy version stamped on every passport
- Escalation when confidence < 85% or warnings fire

---

**Speaker note:** Judges care about hallucination — emphasize rules + citations.
