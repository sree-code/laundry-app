# Slide 2 — The Problem

## Travel policy is hard — and personal

- Non-rev and standby rules depend on **status, seniority, dependents, partner airlines, and dates**
- **Retiree rules ≠ active employee rules**
- Mistakes = airport stress, compliance risk, and angry gate agents
- Support channels are flooded with the **same repeatable questions**

---

**Speaker note:** The pain isn't "find the PDF." It's "what do *I* do for *this* trip?"
