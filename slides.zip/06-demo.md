# Slide 6 — Live Demo Story

## Meet Sarah — retiree, LAX → ORD, standby, with spouse, partner airline

| Step | What happens |
|------|----------------|
| Profile | Retiree · seniority on file · home base LAX |
| Trip | Nov date → **peak travel warning** |
| Simulate | Retiree check-in (75 min) · spouse rules · partner dress code |
| Citation | Tap step → **Retiree Policy §3.1** highlighted |
| Passport | Print checklist with all citations |
| Escalate | Partner retiree cap → support gets full context JSON |

---

**Speaker note:** Use this script during live demo. Peak date triggers flags — good wow moment.
