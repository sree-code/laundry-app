# Slide 5 — Our Solution

## Don't chat about policy — rehearse your trip

1. **Travel profile** — active vs retiree, seniority, home base
2. **Trip builder** — route, date, partner airline, travelers
3. **Simulate** → step-by-step timeline with risk flags
4. **Every step cites policy** — section, document, version
5. **Compliance Passport** — one page for airport & audit
6. **Smart escalation** — only when policy is ambiguous

---

**Speaker note:** Walk through the 6 steps like a user journey, not a feature list.
