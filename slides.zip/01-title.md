# Slide 1 — Title

## Travel Privilege Copilot

### Rehearse your trip. Travel compliant.

*Policy-grounded trip simulator for non-rev & standby travel*

---

**Team:** [Your names]  
**Hackathon:** [Event name]

---

**Speaker note:** Hook in one line — we're not building another travel chatbot.
