# Slide 3 — What Travelers Actually Need

## Three questions every traveler asks

1. **Am I eligible** for this trip?
2. **What do I do step-by-step** — listing, check-in, dress, documents?
3. **Can I prove** I followed policy?

A FAQ or chatbot only partially answers #1 and #2.

It rarely answers #3.

---

**Speaker note:** Compliance and confidence matter as much as information.
