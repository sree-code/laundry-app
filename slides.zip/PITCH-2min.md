# 2-Minute Spoken Pitch

Read alongside slides **1 → 5 → 6 → 10**.

---

**[0:00]** Fourteen teams will build a travel-policy chatbot. We built something different: **Travel Privilege Copilot** — so employees and retirees can **rehearse** standby and non-rev trips **before** they book.

**[0:20]** Policy isn't one-size-fits-all. It depends on your status, seniority, dependents, partner airline, and travel date. Retirees aren't active employees. Support is drowning in the same questions. And when a chatbot is wrong, there's no audit trail — just "the bot said."

**[0:40]** Our copilot: set your profile once, build a trip, hit **Simulate**. You get a full timeline — listing, dress code, check-in window, documents, baggage — with **risk flags** for your situation. Every step links to the **exact policy section**. Then export a **Compliance Passport** — one page for the airport and for audit.

**[1:00]** Demo: Sarah, retiree, LAX to ORD, standby with spouse on a partner airline, peak holiday date. She sees retiree check-in rules, spouse eligibility, partner dress code, peak warnings — all cited. If something's ambiguous, we don't fake confidence. We **escalate to support with a structured context packet**, not a chat log.

**[1:25]** Under the hood: a **rules engine** decides eligibility; policy corpus supplies citations. The LLM doesn't invent rules — it explains what the rules already determined.

**[1:40]** Personalized, accurate, compliant, and built to cut support load. **Travel Privilege Copilot: rehearse your trip, travel confident.** Thank you.
