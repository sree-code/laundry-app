# Travel Privilege Copilot — Full Slide Deck

> One-file version. Individual slides are in this folder as `01-title.md` … `10-close.md`.

---

# Slide 1 — Title

## Travel Privilege Copilot

### Rehearse your trip. Travel compliant.

*Policy-grounded trip simulator for non-rev & standby travel*

**Team:** [Your names] | **Hackathon:** [Event name]

---

# Slide 2 — The Problem

## Travel policy is hard — and personal

- Non-rev and standby rules depend on **status, seniority, dependents, partner airlines, and dates**
- **Retiree rules ≠ active employee rules**
- Mistakes = airport stress, compliance risk, and angry gate agents
- Support channels are flooded with the **same repeatable questions**

---

# Slide 3 — What Travelers Actually Need

## Three questions every traveler asks

1. **Am I eligible** for this trip?
2. **What do I do step-by-step** — listing, check-in, dress, documents?
3. **Can I prove** I followed policy?

A FAQ or chatbot only partially answers #1 and #2. It rarely answers #3.

---

# Slide 4 — Why Not a Chatbot?

## 14 teams will build a chatbot. Here's the gap.

| Chatbot | Travel Privilege Copilot |
|--------|---------------------------|
| Reactive — user must ask | **Proactive** — simulates before travel |
| One question at a time | **Full trip timeline** in one click |
| Sounds personal | **Actually personalized** (profile + itinerary) |
| LLM may hallucinate | **Rules engine** + **mandatory citations** |
| Chat log at escalation | **Structured context packet** for support |
| Nothing to show at the gate | **Compliance Passport** (printable checklist) |

---

# Slide 5 — Our Solution

## Don't chat about policy — rehearse your trip

1. **Travel profile** — active vs retiree, seniority, home base
2. **Trip builder** — route, date, partner airline, travelers
3. **Simulate** → step-by-step timeline with risk flags
4. **Every step cites policy** — section, document, version
5. **Compliance Passport** — one page for airport & audit
6. **Smart escalation** — only when policy is ambiguous

---

# Slide 6 — Live Demo Story

## Meet Sarah — retiree, LAX → ORD, standby, with spouse, partner airline

| Step | What happens |
|------|----------------|
| Profile | Retiree · seniority on file · home base LAX |
| Trip | Nov date → **peak travel warning** |
| Simulate | Retiree check-in (75 min) · spouse rules · partner dress code |
| Citation | Tap step → **Retiree Policy §3.1** highlighted |
| Passport | Print checklist with all citations |
| Escalate | Partner retiree cap → support gets full context JSON |

---

# Slide 7 — How It Works (Architecture)

## Accurate because rules decide — AI only explains

```
Profile + Trip → Rules engine → Trip simulation + risk flags
                      ↑
              Policy corpus (mandatory citations)
```

- **No answer without a policy citation**
- Policy version stamped on every passport
- Escalation when confidence < 85% or warnings fire

---

# Slide 8 — Impact

| Metric | Target |
|--------|--------|
| Citation coverage | 100% of simulation steps |
| Golden-path scenarios | Employee, retiree, spouse, partner, peak |
| Time to confidence | < 2 minutes profile → passport |
| Support deflection | Top FAQ scenarios without escalation |
| Escalation quality | Full context, not chat transcript |

---

# Slide 9 — Differentiation

## Chatbot = FAQ. Copilot = trip rehearsal.

- **Proactive** — mistakes prevented before booking
- **Auditable** — compliance team can verify § references
- **Practical** — travelers carry a passport, not a chat history
- **Built** — working MVP (React + rules engine + policy corpus)

**Future:** LLM for plain-language on top of cited simulation

---

# Slide 10 — Close

## Travel Privilege Copilot — Rehearse your trip. Travel compliant.

**Problem:** Complex, personal, compliance-critical travel policy

**Solution:** Simulate → cite → passport → escalate with context

**Ask:** Pilot with travel support on top 10 standby scenarios

### Thank you — questions?
