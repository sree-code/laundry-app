# Travel Privilege Copilot

Policy-grounded trip simulator for non-rev and standby travel. Rehearse your journey before you book — with mandatory policy citations and a printable Compliance Passport.

**Tagline:** Don't chat about travel policy — rehearse your trip and travel compliant.

## Features

- **Travel profile** — Active employee or retiree, seniority, home base (saved locally)
- **Trip builder** — Route, date, standby/non-rev, partner airline, travelers
- **Trip simulation** — Step-by-step timeline: eligibility, listing, dress code, check-in, baggage
- **Risk flags** — Peak travel, partner caps, retiree restrictions
- **Policy citations** — Every step links to official policy section + version
- **Compliance Passport** — Printable checklist with citations for airport and audit
- **Smart escalation** — Context packet for support when policy is ambiguous

## Architecture

| Layer | Implementation |
|-------|----------------|
| Rules engine | `src/data/rules.json` + `src/lib/simulation.js` |
| Policy corpus | `src/data/policies.json` (RAG-ready chunks with section IDs) |
| UI | React + Vite |
| Citations | Mandatory on every simulation step |
| LLM | Not required for MVP — rules decide, text explains |

## Quick start

```bash
cd travel-planner
npm install
npm run dev
```

Open http://localhost:5173

## Demo scenario

1. Set profile: **Retiree**, seniority date, home base **LAX**
2. Trip: **LAX → ORD**, add **spouse**, select a **partner airline**
3. Pick a date in **November** or **December** for peak travel flags
4. Click **Simulate trip** → review timeline and citations
5. **Print / save PDF** from Compliance Passport
6. If escalation banner appears → **Escalate with context**

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Development server |
| `npm run build` | Production build |
| `npm run preview` | Preview production build |

## Hackathon differentiation

Unlike generic chatbots, this app:

- Simulates **before** travel (proactive, not reactive Q&A)
- Personalizes by **profile + itinerary**
- Proves accuracy with **cited policy sections**
- Reduces support load via **Compliance Passport** and structured escalation

## License

MIT
