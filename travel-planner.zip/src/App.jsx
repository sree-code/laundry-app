import { useState } from 'react';
import ProfileForm from './components/ProfileForm';
import TripBuilder from './components/TripBuilder';
import SimulationTimeline from './components/SimulationTimeline';
import CitationPanel from './components/CitationPanel';
import CompliancePassport from './components/CompliancePassport';
import EscalationModal from './components/EscalationModal';
import { useProfile, defaultTrip } from './hooks/useProfile';
import { buildSimulation } from './lib/simulation';

function App() {
  const [profile, setProfile] = useProfile();
  const [trip, setTrip] = useState({
    ...defaultTrip,
    date: new Date().toISOString().slice(0, 10),
  });
  const [simulation, setSimulation] = useState(null);
  const [selectedStepId, setSelectedStepId] = useState(null);
  const [escalationOpen, setEscalationOpen] = useState(false);
  const [error, setError] = useState('');

  const handleSimulate = () => {
    if (!trip.date) {
      setError('Please select a travel date.');
      return;
    }
    if (trip.origin === trip.destination) {
      setError('Origin and destination must differ.');
      return;
    }
    setError('');
    const result = buildSimulation(profile, trip);
    setSimulation(result);
    setSelectedStepId(result.steps[0]?.id ?? null);
  };

  const selectedStep = simulation?.steps.find((s) => s.id === selectedStepId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="app">
      <header className="site-header">
        <div className="header-inner">
          <div className="logo-mark">✈</div>
          <div>
            <h1>Travel Privilege Copilot</h1>
            <p className="tagline">Rehearse your trip. Travel compliant.</p>
          </div>
        </div>
      </header>

      <main className="main-layout">
        <aside className="sidebar">
          <ProfileForm profile={profile} onChange={setProfile} />
          <TripBuilder trip={trip} onChange={setTrip} onSimulate={handleSimulate} />
          {error && <div className="error-banner">{error}</div>}
        </aside>

        <div className="content">
          {simulation ? (
            <>
              <SimulationTimeline
                simulation={simulation}
                selectedStepId={selectedStepId}
                onSelectStep={setSelectedStepId}
              />
              <div className="content-row">
                <CitationPanel step={selectedStep} />
                <CompliancePassport
                  profile={profile}
                  trip={trip}
                  simulation={simulation}
                  onPrint={handlePrint}
                />
              </div>
              {simulation.meta.needsEscalation && (
                <div className="escalation-banner">
                  <p>Some steps need human review before you travel.</p>
                  <button
                    type="button"
                    className="btn btn-warning"
                    onClick={() => setEscalationOpen(true)}
                  >
                    Escalate with context
                  </button>
                </div>
              )}
            </>
          ) : (
            <section className="card welcome-card">
              <h2>Welcome</h2>
              <p>
                Set your travel profile, build a standby or non-rev trip, and hit <strong>Simulate trip</strong>.
                You&apos;ll get a step-by-step timeline with mandatory policy citations and a printable Compliance Passport.
              </p>
              <ul className="welcome-list">
                <li>Personalized for active employees and retirees</li>
                <li>Rules engine + cited policy — AI explains, rules decide</li>
                <li>Smart escalation when policy is ambiguous</li>
              </ul>
              <p className="muted demo-hint">
                Try: Retiree · LAX → ORD · spouse · partner airline · holiday date
              </p>
            </section>
          )}
        </div>
      </main>

      <EscalationModal
        open={escalationOpen}
        onClose={() => setEscalationOpen(false)}
        profile={profile}
        trip={trip}
        simulation={simulation}
      />
    </div>
  );
}

export default App;
