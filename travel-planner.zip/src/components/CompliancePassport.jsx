import { POLICY_VERSION, POLICY_EFFECTIVE_DATE } from '../lib/simulation';

export default function CompliancePassport({ profile, trip, simulation, onPrint }) {
  if (!simulation) return null;

  const travelerList = [
    profile.name || 'Traveler',
    trip.travelers.spouse ? 'Spouse/partner' : null,
    trip.travelers.dependents > 0 ? `${trip.travelers.dependents} dependent(s)` : null,
  ].filter(Boolean);

  return (
    <section className="card passport-card" id="compliance-passport">
      <div className="passport-header">
        <h2>Compliance passport</h2>
        <button type="button" className="btn btn-secondary" onClick={onPrint}>
          Print / save PDF
        </button>
      </div>
      <div className="passport-body">
        <div className="passport-row">
          <span className="passport-label">Traveler</span>
          <span>{profile.name || '—'} ({profile.employeeType})</span>
        </div>
        <div className="passport-row">
          <span className="passport-label">Route</span>
          <span>{trip.origin} → {trip.destination}</span>
        </div>
        <div className="passport-row">
          <span className="passport-label">Date</span>
          <span>{trip.date}</span>
        </div>
        <div className="passport-row">
          <span className="passport-label">Type</span>
          <span>{trip.travelType} · {trip.partnerAirline}</span>
        </div>
        <div className="passport-row">
          <span className="passport-label">Party</span>
          <span>{travelerList.join(', ')}</span>
        </div>
        <hr />
        <h3>Checklist</h3>
        <ul className="passport-checklist">
          {simulation.steps.map((s) => (
            <li key={s.id}>
              <input type="checkbox" readOnly />
              <span>
                <strong>{s.title}</strong>
                <span className="muted small"> — {s.citation?.label}</span>
              </span>
            </li>
          ))}
        </ul>
        <footer className="passport-footer">
          <p>Last verified against policy v{POLICY_VERSION} ({POLICY_EFFECTIVE_DATE})</p>
          <p className="muted small">Generated {new Date(simulation.meta.generatedAt).toLocaleString()}</p>
        </footer>
      </div>
    </section>
  );
}
