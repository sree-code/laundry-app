import { AIRPORTS } from '../hooks/useProfile';
import { rules } from '../lib/simulation';

export default function TripBuilder({ trip, onChange, onSimulate }) {
  return (
    <section className="card">
      <h2>Build trip</h2>
      <div className="form-grid">
        <label>
          From
          <select
            value={trip.origin}
            onChange={(e) => onChange({ ...trip, origin: e.target.value })}
          >
            {AIRPORTS.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </label>
        <label>
          To
          <select
            value={trip.destination}
            onChange={(e) => onChange({ ...trip, destination: e.target.value })}
          >
            {AIRPORTS.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </label>
        <label>
          Travel date
          <input
            type="date"
            value={trip.date}
            onChange={(e) => onChange({ ...trip, date: e.target.value })}
            required
          />
        </label>
        <label>
          Travel type
          <select
            value={trip.travelType}
            onChange={(e) => onChange({ ...trip, travelType: e.target.value })}
          >
            <option value="standby">Standby</option>
            <option value="non-rev">Non-rev (space available)</option>
          </select>
        </label>
        <label>
          Partner airline
          <select
            value={trip.partnerAirline}
            onChange={(e) => onChange({ ...trip, partnerAirline: e.target.value })}
          >
            {rules.partnerAirlines.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </label>
      </div>
      <fieldset className="travelers-fieldset">
        <legend>Travelers</legend>
        <label className="checkbox-label">
          <input type="checkbox" checked disabled />
          Self (required)
        </label>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={trip.travelers.spouse}
            onChange={(e) =>
              onChange({
                ...trip,
                travelers: { ...trip.travelers, spouse: e.target.checked },
              })
            }
          />
          Spouse / partner
        </label>
        <label>
          Dependents (count)
          <input
            type="number"
            min={0}
            max={6}
            value={trip.travelers.dependents}
            onChange={(e) =>
              onChange({
                ...trip,
                travelers: {
                  ...trip.travelers,
                  dependents: parseInt(e.target.value, 10) || 0,
                },
              })
            }
          />
        </label>
      </fieldset>
      <button type="button" className="btn btn-primary" onClick={onSimulate}>
        Simulate trip
      </button>
    </section>
  );
}
