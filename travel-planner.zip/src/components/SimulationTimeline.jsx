export default function SimulationTimeline({ simulation, selectedStepId, onSelectStep }) {
  if (!simulation) return null;

  const phases = [...new Set(simulation.steps.map((s) => s.phase))];

  return (
    <section className="card timeline-card">
      <div className="timeline-header">
        <h2>Trip simulation</h2>
        <span className="badge">Policy v{simulation.meta.policyVersion}</span>
      </div>

      {simulation.flags.length > 0 && (
        <div className="flags">
          {simulation.flags.map((f, i) => (
            <div key={i} className={`flag flag-${f.level}`}>{f.message}</div>
          ))}
        </div>
      )}

      {phases.map((phase) => (
        <div key={phase} className="phase-group">
          <h3 className="phase-title">{phase}</h3>
          <ol className="timeline">
            {simulation.steps
              .filter((s) => s.phase === phase)
              .map((step) => (
                <li
                  key={step.id}
                  className={`timeline-item ${selectedStepId === step.id ? 'selected' : ''} ${step.confidence < 0.85 ? 'low-confidence' : ''}`}
                  onClick={() => onSelectStep(step.id)}
                >
                  <div className="timeline-dot" />
                  <div className="timeline-content">
                    <div className="timeline-title-row">
                      <strong>{step.title}</strong>
                      {step.confidence < 1 && (
                        <span className="confidence-tag">
                          {Math.round(step.confidence * 100)}% confidence
                        </span>
                      )}
                    </div>
                    <p>{step.description}</p>
                    {step.citation && (
                      <button
                        type="button"
                        className="citation-link"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectStep(step.id);
                        }}
                      >
                        {step.citation.label}
                      </button>
                    )}
                  </div>
                </li>
              ))}
          </ol>
        </div>
      ))}
    </section>
  );
}
