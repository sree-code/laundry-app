import { buildEscalationPacket } from '../lib/simulation';

export default function EscalationModal({ open, onClose, profile, trip, simulation }) {
  if (!open || !simulation) return null;

  const packet = buildEscalationPacket(profile, trip, simulation);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(JSON.stringify(packet, null, 2));
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>Escalate to travel support</h2>
        <p className="muted">
          Policy ambiguity detected. This context packet is pre-filled for support — not a vague chat log.
        </p>
        <pre className="escalation-packet">{JSON.stringify(packet, null, 2)}</pre>
        <div className="modal-actions">
          <button type="button" className="btn btn-primary" onClick={copyToClipboard}>
            Copy context packet
          </button>
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
