export default function CitationPanel({ step }) {
  if (!step?.citation) {
    return (
      <section className="card citation-panel empty">
        <h2>Policy citation</h2>
        <p className="muted">Select a simulation step to view the source policy.</p>
      </section>
    );
  }

  const c = step.citation;
  return (
    <section className="card citation-panel">
      <h2>Policy citation</h2>
      <div className="citation-meta">
        <span className="mono">{c.label}</span>
        <span className="muted">v{c.version} · effective {c.effectiveDate}</span>
      </div>
      <h3>{c.sectionTitle}</h3>
      <blockquote className="policy-quote">{c.text}</blockquote>
      <p className="muted small">Every guidance item is tied to an official policy section.</p>
    </section>
  );
}
