import { AIRPORTS } from '../hooks/useProfile';

export default function ProfileForm({ profile, onChange }) {
  return (
    <section className="card">
      <h2>Travel profile</h2>
      <p className="muted">Saved locally — personalize every simulation.</p>
      <div className="form-grid">
        <label>
          Full name
          <input
            type="text"
            value={profile.name}
            onChange={(e) => onChange({ ...profile, name: e.target.value })}
            placeholder="Sarah Chen"
          />
        </label>
        <label>
          Status
          <select
            value={profile.employeeType}
            onChange={(e) => onChange({ ...profile, employeeType: e.target.value })}
          >
            <option value="active">Active employee</option>
            <option value="retiree">Retiree</option>
          </select>
        </label>
        <label>
          Seniority date
          <input
            type="date"
            value={profile.seniorityDate}
            onChange={(e) => onChange({ ...profile, seniorityDate: e.target.value })}
          />
        </label>
        <label>
          Home base
          <select
            value={profile.homeBase}
            onChange={(e) => onChange({ ...profile, homeBase: e.target.value })}
          >
            <option value="">Select airport</option>
            {AIRPORTS.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </label>
      </div>
    </section>
  );
}
