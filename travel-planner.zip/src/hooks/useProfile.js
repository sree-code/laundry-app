import { useState, useEffect } from 'react';

const STORAGE_KEY = 'travel-copilot-profile';

const defaultProfile = {
  name: '',
  employeeType: 'active',
  seniorityDate: '',
  homeBase: '',
};

export function useProfile() {
  const [profile, setProfile] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? { ...defaultProfile, ...JSON.parse(saved) } : defaultProfile;
    } catch {
      return defaultProfile;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  }, [profile]);

  return [profile, setProfile];
}

export const AIRPORTS = [
  'LAX', 'ORD', 'JFK', 'DFW', 'ATL', 'DEN', 'SFO', 'SEA', 'MIA', 'PHX',
  'LHR', 'CDG', 'FRA', 'DXB', 'NRT', 'SYD',
];

export const defaultTrip = {
  origin: 'LAX',
  destination: 'ORD',
  date: '',
  travelType: 'standby',
  partnerAirline: 'None (company only)',
  travelers: { self: true, spouse: false, dependents: 0 },
};
